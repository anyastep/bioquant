<?php

namespace Drupal\Tests\bootstrap_barrio\Functional;


/**
 * Tests the Bootstrap Barrio theme.
 *
 * @group claro
 */
class BootstrapBarrioSubThemeTest extends BootstrapBarrioTest {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'bootstrap_barrio_subtheme';

}
